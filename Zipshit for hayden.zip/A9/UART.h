/*
* UART.h
*
*  Created on: May 25, 2020
*      Author: Anthony
*/

#ifndef UART_H_
#define UART_H_

void UART_transmit(uint32_t data);
void init_UART0();

#endif /* UART_H_ */
