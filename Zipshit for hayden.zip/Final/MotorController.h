/*
 * MotorController.h
 *
 *  Created on: May 31, 2020
 *      Author: Hayden
 */

#ifndef MOTORCONTROLLER_H_
#define MOTORCONTROLLER_H_

void squareOutput(double frequency, int dutyCycleTotal);
void squareOutputSound(double frequency, int dutyCycleTotal);

#endif /* MOTORCONTROLLER_H_ */
