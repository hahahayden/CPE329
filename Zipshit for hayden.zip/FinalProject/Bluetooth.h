/*
 * Bluetooth.h
 *
 *  Created on: Jun 1, 2020
 *      Author: Anthony
 */

#ifndef BLUETOOTH_H_
#define BLUETOOTH_H_

void initScreen();

#endif /* BLUETOOTH_H_ */
