/*
* EEPROM.h
*
*  Created on: May 26, 2020
*      Author: Anthony
*/

#ifndef EEPROM_H_
#define EEPROM_H_

void InitEEPROM(uint8_t DeviceAddress);

#endif /* EEPROM_H_ */
