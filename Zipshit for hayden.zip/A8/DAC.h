/*
* DAC.h
*
*  Created on: May 7, 2020
*      Author: Hayden
*/
#ifndef DAC_H_
#define DAC_H_

void startDAC();
void dataDAC(uint16_t data);
void setSquare();

#endif /* DAC_H_ */
